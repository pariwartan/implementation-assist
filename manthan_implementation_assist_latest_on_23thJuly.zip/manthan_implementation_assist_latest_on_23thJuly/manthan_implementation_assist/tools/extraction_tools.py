import base64
import os
import requests
from repository.implementation_repository import *


from langchain_core.tools import tool


@tool
def ask_upload():
    """call this if user asks to upload the required files on left side panel"""
    pass

@tool
def required_files(source_hcm, target_hcm) -> dict:
    """call this to get all required files for source_hcm and target_hcm"""
    required_files = get_required_files(source_hcm, target_hcm)
    print("-================", required_files)
    return {"messages": required_files}

@tool
def classify_file() -> dict:
    """call this if user requests to classify the information"""
    print("----------------------file_classification+++++++++++++++++++++++++++++")
    project_dir = os.path.dirname(os.path.abspath(__file__))
    project_dir = os.path.split(project_dir)
    temp_folder = os.path.join(project_dir[0], 'temp')
    # print("temppppp", temp_folder)
    # print("----------------------file_extractor+++++++++++++++++++++++++++++")
    data = ["direct_deposit.pdf", "employee_earning.pdf"]
    # st.session_state.localStore.append(data['intermediate_steps'][0][-1])
    # local_session_adder(data)
    # print(data['agent_outcome'])
    base_path = temp_folder
    # print("baseeeeeeeeeeeee",base_path)
    base64File = ""
    for file in data:
        path = os.path.join(base_path, file)
        if ("direct" in file):
            base64File = base64.b64encode(open(path, "rb").read())
            break
    json_data = {'pdf': base64File.decode('utf-8')}
    response = requests.post("https://us-central1-image-processing-415012.cloudfunctions.net/extract_dd_azure",
                             json=json_data)

    # Check the response
    if response.status_code == 200:
        print("DOC AI Request was successful!")
    else:
        print("Request failed with status code:", response.status_code)
        print("Response:", response.text)
        response = response.text
    print("response of extraction", response)
    return {"messages": response}
    # return {"messages":"classification is successful"}

@tool
def extract_file() -> dict:
    """call this If user requests to extract the information"""
    print("----------------------file_extractor+++++++++++++++++++++++++++++")
    project_dir = os.path.dirname(os.path.abspath(__file__))
    project_dir = os.path.split(project_dir)
    temp_folder = os.path.join(project_dir[0], 'temp')
    # print("temppppp",temp_folder)
    # print("----------------------file_extractor+++++++++++++++++++++++++++++")
    data = ["direct_deposit.pdf", "employee_earning.pdf"]
    # st.session_state.localStore.append(data['intermediate_steps'][0][-1])
    # local_session_adder(data)
    # print(data['agent_outcome'])
    base_path = temp_folder
    # print("baseeeeeeeeeeeee",base_path)
    base64File = ""
    for file in data:
        path = os.path.join(base_path, file)
        if ("direct" in file):
            base64File = base64.b64encode(open(path, "rb").read())
            break
    json_data = {'pdf': base64File.decode('utf-8')}
    response = requests.post("https://us-central1-image-processing-415012.cloudfunctions.net/extract_dd_azure",
                             json=json_data)

    # Check the response
    if response.status_code == 200:
        print("DOC AI Request was successful!")
    else:
        print("Request failed with status code:", response.status_code)
        print("Response:", response.text)
        response = response.text
    print("response of extraction",response.text)
    return {"messages":response.text}
