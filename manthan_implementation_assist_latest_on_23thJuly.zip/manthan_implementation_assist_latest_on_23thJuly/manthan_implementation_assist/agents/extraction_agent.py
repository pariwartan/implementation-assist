# File Extraction Agent
from typing import Literal

from langgraph.constants import END
from langgraph.prebuilt import tools_condition

from prompts.extraction_agent_prompts import extraction_agent_prompt
from config.llm_config import getChatOpenAILLM

from tools.extraction_tools import *
from tools.common_tools import CompleteOrEscalate
from state.implementation_state import ImplementationState
from langchain_core.pydantic_v1 import BaseModel, Field
# get appropriate LLM from LLLConfig

class AskUpload(BaseModel):
    """Ask user to upload the required file on the left side panel """
    question: str

llm = getChatOpenAILLM(temperature=0)

extraction_safe_tools = [required_files, classify_file, extract_file]
# extraction_sensitive_tools = [upload_file]
extraction_tools = extraction_safe_tools

extraction_agent_runnable = extraction_agent_prompt | llm.bind_tools(
    extraction_tools + [ AskUpload, CompleteOrEscalate]
)

def route_extraction_agent(
    state: ImplementationState,
) -> Literal[
    "ask_upload",
    # "extraction_sensitive_tools",
    "extraction_safe_tools",
    "goto_implementation_assistant",
    "__end__",
]:
    route = tools_condition(state)
    if route == END:
        return END
    tool_calls = state["messages"][-1].tool_calls
    did_cancel = any(tc["name"] == CompleteOrEscalate.__name__ for tc in tool_calls)
    if did_cancel:
        return "goto_implementation_assistant"
    if tool_calls[0]["name"] == AskUpload.__name__:
        return "ask_upload"
    safe_tool_names = [t.name for t in extraction_safe_tools]
    if all(tc["name"] in safe_tool_names for tc in tool_calls):
        return "extraction_safe_tools"
    return "extraction_sensitive_tools"