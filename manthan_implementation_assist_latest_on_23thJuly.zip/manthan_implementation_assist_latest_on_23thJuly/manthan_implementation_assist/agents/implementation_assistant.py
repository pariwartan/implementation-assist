from typing import Literal

from langchain_core.pydantic_v1 import BaseModel, Field
from langchain_core.runnables import Runnable, RunnableConfig
from langgraph.constants import END
from langgraph.prebuilt import tools_condition

from state.implementation_state import ImplementationState
from prompts.implementation_assistant_prompts import implementation_assistant_prompt
from tools.implementation_assistant_tools import *
from config.llm_config import getChatOpenAILLM


class ImplementationAssistant:
    def __init__(self, runnable: Runnable):
        self.runnable = runnable

    def __call__(self, state: ImplementationState, config: RunnableConfig):
        while True:
            result = self.runnable.invoke(state)

            if not result.tool_calls and (
                not result.content
                or isinstance(result.content, list)
                and not result.content[0].get("text")
            ):
                messages = state["messages"] + [("user", "Respond with a real output.")]
                state = {**state, "messages": messages}
                messages = state["messages"] + [("user", "Respond with a real output.")]
                state = {**state, "messages": messages}
            else:
                break
        return {"messages": result}



class ToExtractionAgent(BaseModel):
    """Transfers work to a specialized assistant to handle file extraction."""

    request: str = Field(
        description="for any necessary followup questions, the extraction agent should clarify before proceeding."
    )

class AskHuman(BaseModel):
    """If required details source hcm, target hcm and salesorderid for onboarding the client are not available
    then ask the user else ask user permission to start onboarding process for existing details"""
    question: str


# The top-level assistant performs general Q&A and delegates specialized tasks to other assistants.
# The task delegation is a simple form of semantic routing / does simple intent detection
llm = getChatOpenAILLM(temperature=0)


implementation_assistant_tools = [
    # initiate_implementation,
    # bind_implementation,
    # get_implementation_info,
    implementation_info,
    list_implementations,

]

implementation_initiate_tools = [
    initiate_implementation, bind_implementation,
]

implementation_assistant_runnable = implementation_assistant_prompt | llm.bind_tools(
    implementation_initiate_tools + implementation_assistant_tools
    + [
        ToExtractionAgent,
        AskHuman
    ]
)

def route_implementation_assistant(
    state: ImplementationState,
) -> Literal[
    "implementation_assistant_tools",
    "enter_extraction_agent",
    "ask_human"
    "implementation_initiate_tools",
    "__end__",
]:
    route = tools_condition(state)
    if route == END:
        return END
    tool_calls = state["messages"][-1].tool_calls
    if tool_calls:
        print("printing current tool name........")
        print(tool_calls[0]["name"])
        if tool_calls[0]["name"] == ToExtractionAgent.__name__:
            return "enter_extraction_agent"
        if tool_calls[0]["name"] == AskHuman.__name__:
            return "ask_human"
        safe_toolnames = [t.name for t in implementation_assistant_tools]
        if all(tc["name"] in safe_toolnames for tc in tool_calls):
            return "implementation_assistant_tools"
        return "implementation_initiate_tools"
        # elif tool_calls[0]["name"] == ToHotelBookingAssistant.__name__:
        #     return "enter_book_hotel"
        # elif tool_calls[0]["name"] == ToBookExcursion.__name__:
        #     return "enter_book_excursion"
    raise ValueError("Invalid route")

# Each delegated workflow can directly respond to the user
# When the user responds, we want to return to the currently active workflow
def route_to_workflow(
    state: ImplementationState,
) -> Literal[
    "implementation_assistant",
    "extraction_agent",
    # "book_car_rental",
    # "book_hotel",
    # "book_excursion",
]:
    """If we are in a delegated state, route directly to the appropriate assistant."""
    dialog_state = state.get("dialog_state")
    if not dialog_state:
        return "implementation_assistant"
    return dialog_state[-1]
