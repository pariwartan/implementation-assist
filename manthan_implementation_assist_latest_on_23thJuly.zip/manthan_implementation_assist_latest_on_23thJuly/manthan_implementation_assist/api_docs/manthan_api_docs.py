import json

project_manthan_api_docs = {
    "base_url": "http://127.0.0.1:5000/",
    "endpoints": {
        "/manthan/v1/implementation.initiate": {
            "method": "POST",
            "description": "initiate implementation for onboarding",
            "parameters": None,
            "header": "Authorization, ADP-ConversationID, ADP-MessageID, Originator-ApplicationID",
            "request": {
                "implementationName": "WFN Onboarding",
                "salesforceId": "12387897987"
            },
            "response": {
                "description": "A JSON object containing complete response from API.",
                "content_type": "application/json"
            }
        },

        "/manthan/v1/implementation.bind": {
            "method": "POST",
            "description": "Bind the implementation object to the ADP domain (payroll, benefits time etc) for onboarding",
            "parameters": None,
            "header": "Authorization, ADP-ConversationID, ADP-MessageID, Originator-ApplicationID",
            "request": {
                "implementationRefID": "ecd4cca5-bcce-4c29-8512-7d368ed5f10f",
                "sourceHCMRef": {
                    "name": "Paylocity",
                    "version": "7.1.8",
                    "databaseExportIndicator": "false"
                },
                "domains": [
                    {
                        "name": "payroll",
                        "bindProperties": [{
                            "key": "regionCode",
                            "value": "NA"
                        }
                        ]
                    }
                ]
            },
            "response": {
                "description": "A JSON object containing complete response from API.",
                "content_type": "application/json"
            }
        },

        "/manthan/v1/validations/{validation-ref-id}/status": {
            "method": "GET",
            "description": "Get the validation request status from the earlier performed validation",
            "parameters": "validation-ref-id",
            "header": "Authorization, ADP-ConversationID, ADP-MessageID, Originator-ApplicationID",
            "request": {
                "validation-ref-id": 123
            },
            "response": {
                "description": "A JSON object containing complete response from API.",
                "content_type": "application/json"
            }
        },

        "/manthan/implementation-api/v1/implementations/{implementation-ref-id}": {
            "method": "GET",
            "description": "Displays the requested implementation instance using the provided implementation reference id with all the binds associated with the implementation.",
            "header": "Authorization, ADP-ConversationID, ADP-MessageID, Originator-ApplicationID",
            "request": {
                "implementation-ref-id": 123
            },
            "response": {
                "description": "A JSON object containing complete response from API.",
                "content_type": "application/json"
            }
        },

        "/manthan/implementation-api/v1/implementations/{implementation-ref-id}/document.upload": {
            "method": "POST",
            "description": """Upload a document for the provided implementation reference. The documents could be structured (JSON, XLS, CSV etc. ) or
unstructured (text, PDF, Images etc. ). Documents could also include notes from the interactions withs the customer.""",
            "header": "Content-Type, Content-Length, Content-Disposition, Authorization, ADP-ConversationID, ADP-MessageID, Originator-ApplicationID",
            "request": {
                "implementation-ref-id": 123
            },
            "response": {
                "description": "A JSON object containing complete response from API.",
                "content_type": "application/json"
            }
        },

        "/manthan/implementation-api/v1/implementation.validate": {
            "method": "POST",
            "description": """Validates the information in the ADP interim format which is extracted from the uploaded documents. Validation will include all possible
validations - formats, sizes, references in other systems, business rules etc. It is expected to finish all validations that could fail any of
the steps happening later""",
            "header": "Authorization, ADP-ConversationID, ADP-MessageID, Originator-ApplicationID",
            "request": {
                "implementationRefID": "ecd4cca5-bcce-4c29-8512-7d368ed5f10f",
                "extractionRefID": "xrd4cca5-bcce-4c29-8512-7d368ed5f10f",
                "callback": {
                    "uri": "https://wfn.adp.com/launchpad/manthan/validation-status",
                    "oAuthIndicator": "false"
                }
            },
            "response": {
                "description": "A JSON object containing complete response from API.",
                "content_type": "application/json"
            }
        },

        "/manthan/implementation-api/v1/implementation.transformation": {
            "method": "POST",
            "description": """Transform the data from HCM specific extracted information in interim database to ADP Fixed format schema.""",
            "header": "Authorization, ADP-ConversationID, ADP-MessageID, Originator-ApplicationID",
            "request": {
                "implementationRefID": "ecd4cca5-bcce-4c29-8512-7d368ed5f10f",
                "extractionRefID": "xrd4cca5-bcce-4c29-8512-7d368ed5f10f",
                "callback": {
                    "uri": "https://wfn.adp.com/launchpad/manthan/transformation-status",
                    "oAuthIndicator": "false"
                }
            },
            "response": {
                "description": "A JSON object containing complete response from API.",
                "content_type": "application/json"
            }
        }
    }
}

project_manthan_api_docs = json.dumps(project_manthan_api_docs, indent=2)
