import certifi
from pymongo.mongo_client import MongoClient
from langchain.tools import tool
from pydantic import BaseModel
from config.db_config import *
import json
from bson.json_util import dumps
from bson.json_util import loads

def get_inprogress_implementations():
    db = getMongoDBClient('Pari108')
    collection = db['manthan_implementations']
    query = {"processingState": "in-process"}
    document = collection.find_one(query)
    inprogress_implementations = ""
    if(document):
        client_details = document.get("client_details", {})
        if(client_details):
            source_hcm = client_details.get("sourceHcm")
            target_hcm = client_details.get("targetHcm")
            salesforce_id = client_details.get("salesforceId")
            inprogress_implementations = "source_hcm:"+source_hcm+", target_hcm:"+target_hcm+",salesforce_id:"+salesforce_id
    return inprogress_implementations

def get_required_files(source_hcm: str, target_hcm: str):
    db = getMongoDBClient('Pari108')
    collection = db['manthan_required_files']
    query = {
        "sourceHcm": {"$regex": source_hcm, "$options": "i"},
        "targetHcm": {"$regex": target_hcm, "$options": "i"}
    }
    documents = collection.find(query)
    print("=== mongo db documents ====", documents)

    required_files = []
    for doc in documents:
        required_files.extend(doc['reqFiles'])

    if not required_files:
        return f"No required files found for sourceHcm {source_hcm} and targetHcm {target_hcm}."
    print("=== mongo db required_files ====", required_files)
    return required_files

def get_required_schema(file_name: str):
    db = getMongoDBClient('Pari108')
    collection = db['file_data_schema']
    query = {"file_name": file_name}
    document = collection.find(query)
    print("documnt: ")
    print(document)
    required_schema = {}

    for doc in document:
        required_schema.update(doc['file_schema'])

    return required_schema

def get_implementations_list():
    db = getMongoDBClient('Pari108')
    collection = db['manthan_implementations']
    query = {}
    document = collection.find(query)
    return list(document)

def get_implementation_info(implementation_ref_id : str):
    db = getMongoDBClient('Pari108')
    collection = db['manthan_implementations']
    query = {
        "implementationsListResponse.implementationRefID": implementation_ref_id
    }
    projection = {
        "implementationsListResponse": {
            "$elemMatch": {
                "implementationRefID": implementation_ref_id
            }
        }
    }
    document = collection.find(query, projection)
    return list(document)

if __name__ == '__main__':
    #print(get_required_files.)
    print(get_required_files('paylocity','wfn'))

# print(get_required_files("paycheck","WFN"))
#print(get_implementations_list)
