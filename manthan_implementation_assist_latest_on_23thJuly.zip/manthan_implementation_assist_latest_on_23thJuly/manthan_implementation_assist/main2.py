import json

import streamlit as st
import os
import uuid
from IPython.display import Image, display
from dotenv import load_dotenv
from langchain.memory import ConversationBufferMemory
from langchain.prompts import PromptTemplate
from langchain.prompts import (
    SystemMessagePromptTemplate
)
from langchain_core.messages import ToolMessage

# from tools.extraction_tools import upload_file
# from tools.extraction_tools import upload_file
from util.common_utils import _print_event
from workflow.implementation_flow_graph import implementation_graph
from state.implementation_state import *
from streamlit_chat import message

project_dir = os.path.dirname(os.path.abspath(__file__))
temp_folder = os.path.join(project_dir, 'temp')

class HumanMessage:
    def __init__(self, content: str, id: str):
        self.content = content
        self.id = id

class AIMessage:
    def __init__(self, content: str, additional_kwargs: dict, response_metadata: dict, id: str):
        self.content = content
        self.additional_kwargs = additional_kwargs
        self.response_metadata = response_metadata
        self.id = id
def main( ):
    try:
        # langchain.debug = True
        thread_id = str(uuid.uuid4())
        _printed = set()
        #implementation_graph = get_implementation_graph()
        config = {
            "configurable": {
                # The passenger_id is used in our flight tools to
                # fetch the user's flight information
                # Checkpoints are accessed by thread_id
                "thread_id": thread_id,
            }
        }
        load_dotenv()
        logo = 'https://images.sftcdn.net/images/t_app-icon-m/p/69c53218-c7a9-11e6-8ce5-5a990553aaad/3424445367/adp-mobile-solutions-logo'
        logo2 = 'https://i.pinimg.com/736x/8b/16/7a/8b167af653c2399dd93b952a48740620.jpg'
        st.set_page_config(page_title="Manthan API Chatbot", page_icon=logo)
        st.header("Manthan API Testing")
        if 'area_key' not in st.session_state:
            st.session_state.area_key = 1
        if 'requests' not in st.session_state:
            st.session_state.requests = []
        if 'required_files' not in st.session_state:
            st.session_state.required_files = []
        if 'responses' not in st.session_state:
            st.session_state['responses'] = ["Hi, I am Project Manthan Testing Bot, How may i assist you?"]
        if 'localStore' not in st.session_state:
            st.session_state.localStore = {}
        if 'upload' not in st.session_state:
            st.session_state.upload = []
        if 'event' not in st.session_state:
            st.session_state.event = {}
        if 'interrupt' not in st.session_state:
            st.session_state.interrupt = 0
        if 'config' not in st.session_state:
            st.session_state.config = []
        if 'intermediate_steps' not in st.session_state:
            st.session_state.intermediate_steps = []
            # system_message = SystemMessagePromptTemplate.from_template(template=manthan_assistant_bot_template)
        system_message = SystemMessagePromptTemplate.from_template(
            template="""Simply return the response as it is , do not change anything""")
        response_container = st.container()
        # container for text box
        textcontainer = st.container()
        # response = " "
        with textcontainer:
            user_question = st.empty()
            user_question = st.chat_input("I am here to help you!", key="input")
            if user_question:
                with st.spinner("Processing"):
                    # prev_response = st.session_state.localStore.get('previous_run_fail')
                    # missing_input = missing_input_status(prev_response)
                    # if missing_input:
                    #     prev_question = st.session_state.requests[-1] if st.session_state.requests else ""
                    # print(st.session_state.localStore.get('previous_chain_responseJson'))
                    if st.session_state.interrupt == 0:
                        print("Step11111111111")
                        events = implementation_graph.stream(
                                {"messages": ("user", user_question)}, config, stream_mode="values" )
                        print("after graph")
                        for event in events:
                            response = _print_event(event, _printed)
                            st.session_state.event = event
                            st.session_state.config = config
                            print("config1111111", config)
                            print("response from graph",response)
                        print("eventttttttttttttt", event)
                        # print("JSONNNNNNNN", json.dumps(event))
                        snapshot = implementation_graph.get_state(config)
                        print(snapshot)
                    # print("testttttt",snapshot.v['messages'][1]['additional_kwargs']['tool_calls'][0]['function']['name'])
                        if snapshot.next:
                            if snapshot.next[0] == "ask_human":
                                target_question = None
                                response = event['messages'][-1].tool_calls[0]['args']['question']
                                # print("humannnnnnnn")
                                # for message2 in event['messages']:
                                #     if isinstance(message2, AIMessage):
                                #         print("messagew11111", message2)
                                #         print("messagew2222", message2)
                                #         tool_calls = message2.additional_kwargs.get('tool_calls', [])
                                #         for tool_call in tool_calls:
                                #             if tool_call.get('name') == 'AskHuman':
                                #                 arguments = tool_call['function']['arguments']
                                #                 arguments_dict = eval(arguments)
                                #                 target_question = arguments_dict.get('question')
                                #                 break
                                #         if target_question:
                                #             break
                                # response = target_question
                                # response = event['messages'][-1].tool_calls[0]['args']['question']
                                # printevent["messages"][-1]
                                # question = event['messages'][-1]['additional_kwargs']['tool_calls'][0]['function']['arguments']
                                # question_dict = eval(question)
                                # response = question_dict['question']
                                # print("question.....",response)
                                # response = event['messages'][-1]['tool_calls'][0]['args']['question']
                                # print("responseeeeeee",event["messages"][-1])
                                # print("responseeeeeee",event['messages'][1].tool_calls[0]['args']['question'] )

                            # if snapshot.next [0] == "implementation_initiate_tools":

                            # We have an interrupt! The agent is trying to use a tool, and the user can approve or deny it
                            # Note: This code is all outside of your graph. Typically, you would stream the output to a UI.
                            # Then, you would have the frontend trigger a new run via an API call when the user has provided input.
                            #     response = "Looks like you are onboarding the client. Please provide source hcm , target hcm and sales orderid"
                    if st.session_state.interrupt == 1:
                        print("step222222222",st.session_state.interrupt)
                        if user_question:
                            print(user_question)
                            event = st.session_state.event
                            config = st.session_state.config
                            print("config22222",config)
                            # Just continue
                            tool_call_id = event["messages"][-1].tool_calls[0]["id"]
                            tool_message = [
                                            {  "tool_call_id": tool_call_id, "type" : "tool",
                                                "content":user_question, }

                        ]
                            implementation_graph.update_state(config, {"messages":tool_message}, as_node="ask_human")
                            print("nexttttttt",implementation_graph.get_state(config).next)
                            events = implementation_graph.stream(
                            None,
                            config,
                                stream_mode="values"
                                )
                            # events = implementation_graph.stream(
                            #     {"messages": ("user", user_question)}, config, stream_mode="values")
                            for event in events:
                                response = _print_event(event, _printed)
                                st.session_state.event = event
                                st.session_state.config = config
                            print("responseeeeeeee22222", event)
                            st.session_state.interrupt = ""
                            snapshot = implementation_graph.get_state(config)
                            print("snapshot extraction.....",snapshot.next)
                            if snapshot.next:
                                if snapshot.next[0]=="ask_human":
                                    response = event['messages'][-1].tool_calls[0]['args']['question']
                                    if user_question:
                                        print(user_question)
                                        event = st.session_state.event
                                        config = st.session_state.config
                                        print("config22222", config)
                                        # Just continue
                                        tool_call_id = event["messages"][-1].tool_calls[0]["id"]
                                        tool_message = [
                                            {"tool_call_id": tool_call_id, "type": "tool",
                                             "content": user_question, }]
                                        implementation_graph.update_state(config, {"messages": tool_message},
                                                                          as_node="ask_human")
                                        print("nexttttttt", implementation_graph.get_state(config).next)
                                        events = implementation_graph.stream(
                                            None,
                                            config,
                                            stream_mode="values"
                                        )
                                        for event in events:
                                            response = _print_event(event, _printed)
                                            st.session_state.event = event
                                            st.session_state.config = config
                                        print("responseeeeeeee22222", event)
                                        st.session_state.interrupt = ""
                                        snapshot = implementation_graph.get_state(config)
                                if snapshot.next[0] == "ask_upload":
                                    target_message = None
                                            # for event_item in event:
                                            # target_message = None
                                            # for message2 in event['messages']:
                                            #     if 'tool_calls' in message2.get('additional_kwargs', {}):
                                            #         for tool_call in message2['additional_kwargs']['tool_calls']:
                                            #             if tool_call.get('name') == 'AskUpload':
                                            #                 target_message = tool_call['args']['question']
                                            #                 break
                                            # print("message target....", target_message)
                                            # response = target_message
                                    response = event['messages'][-1].tool_calls[0]['args']['question']
                                    st.session_state.upload = 'X'
                        else:
                            # Satisfy the tool invocation by
                            # providing instructions on the requested changes / change of mind
                            response = implementation_graph.stream(
                                        #      {
                                        #     "messages": [
                                        #         ToolMessage(
                                        #             tool_call_id=event["messages"][-1].tool_calls[0]["id"],
                                        #             content=f"API call denied by user. Reasoning: '{user_question}'. Continue assisting, accounting for the user's input.",
                                        #         )
                                        #     ]
                                        # },
                                None,
                                        config,
                                stream_mode="values"
                                    )
                        st.session_state.interrupt = 0
                    # snapshot = implementation_graph.get_state(config)
                    else:
                        st.session_state.interrupt = 1


                        # user_question = prepare_input(prev_question, prev_response, user_question)
                    #     response = "test"
                    # print("responseeeee222222",response)
                    st.session_state.requests.append(user_question)
                    st.session_state.responses.append(response)

        if st.session_state.upload == 'X':
            with st.sidebar:
                st.subheader("Your documents")
                pdf_docs = st.file_uploader(
                    "Upload your PDFs here and click on 'Process'", accept_multiple_files=True)
                if st.button("Process"):
                    with st.spinner("Processing"):
                        # upload_file(pdf_docs)
                        uploaded_file_path = temp_folder
                        for uploaded_file in pdf_docs:
                            if uploaded_file is not None:
                                with open(os.path.join(uploaded_file_path, uploaded_file.name),
                                          'wb') as output_temporary_file:
                                    output_temporary_file.write(uploaded_file.read())
                        missing_flag = False
                        print("Checking for missing files------>")
                        for file in st.session_state.required_files:
                            print("File: " + file)
                            path = os.path.join(uploaded_file_path, file)
                            if not os.path.exists(path):
                                missing_flag = True
                                st.session_state.missing_files.append(file)
                        if missing_flag:
                            err_stmt = None
                            err_stmt = "The following files are missing. Please upload them: "
                            for file in st.session_state.missing_files:
                                err_stmt = err_stmt + " " + str(file)
                            st.error(err_stmt)
                        else:
                            event = st.session_state.event
                            config = st.session_state.config
                            tool_call_id = event["messages"][-1].tool_calls[0]["id"]
                            tool_message = [
                                {"tool_call_id": tool_call_id, "type": "tool",
                                 "content": "Uploaded the files", } ]
                            implementation_graph.update_state(config, {"messages": tool_message}, as_node="ask_upload")
                            print("nexttttttt", implementation_graph.get_state(config).next)
                            events = implementation_graph.stream(
                                None,
                                config,
                                stream_mode="values"
                            )
                            for event in events:
                                response = _print_event(event, _printed)
                            st.session_state.interrupt = 0

                            # user_question = st.session_state.requests.pop(-1)
                            # response = implementation_graph.invoke(user_question)

                            message("Data has been extracted from file successfully : ")
                            st.session_state.upload = ' '
                            # st.rerun()
                            st.markdown("""
                                         <style>
                                         [data-testid="stSidebar"] {
                                            position: relative;
                                            width: 800px;
                                            max-width: 2000px;
                                            height: auto;
                                            box-sizing: border-box;
                                            flex-shrink: 0;
                                         }
                                         [data-testid="stFileUploaderDropzone"] {
                                             display: None
                                         }
                                         [data-testid="baseButton-secondary"] {
                                             display: None
                                         }
                                         </style>
                                         """, unsafe_allow_html=True)
                            # st.error(response['finalResponse'])


                            print("_________________________________________________")
                            # st.session_state.intermediate_steps.append(response['intermediate_steps'][0][-1])
                            # st.session_state.requests.append(user_question)
                            # response = response['finalResponse']
                            st.session_state.responses.append(response)
                        with st.sidebar:
                            with st.container(height=300):
                                st.markdown(response)
                        # print("test",response)
        with response_container:
            if st.session_state['responses']:
                for i in range(len(st.session_state['responses'])):
                    message(st.session_state['responses'][i], key=str(i), logo=logo)
                    if i < len(st.session_state['requests']):
                        message(st.session_state["requests"][i], is_user=True, key=str(i) + '_user', logo=logo2)

    except Exception as e:
        st.error("Something went wrong. Please restart the application.")
        print(f"Error details: {str(e)}")




if __name__ == '__main__':
    # print("Hello Langgraph")
    # print(os.environ["OPENAI_API_KEY"])
    main()