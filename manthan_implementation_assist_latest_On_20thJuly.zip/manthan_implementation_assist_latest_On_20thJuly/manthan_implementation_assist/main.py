import streamlit as st
import os
import uuid
from IPython.display import Image, display
from dotenv import load_dotenv
from langchain.memory import ConversationBufferMemory
from langchain.prompts import PromptTemplate
from langchain.prompts import (
    SystemMessagePromptTemplate
)
from langchain_core.messages import ToolMessage

from tools.extraction_tools import upload_file
# from tools.extraction_tools import upload_file
from util.common_utils import _print_event
from workflow.implementation_flow_graph import get_implementation_graph
from state.implementation_state import *
from streamlit_chat import message

def main( ):
    try:
        # langchain.debug = True
        thread_id = str(uuid.uuid4())
        _printed = set()
        implementation_graph = None
        if 'localStore' not in st.session_state:
            st.session_state.localStore = {}
            st.session_state.localStore['implementation_graph'] = get_implementation_graph()
            st.session_state.localStore['thread_id'] = thread_id
        else:
            implementation_graph = st.session_state.localStore.get('implementation_graph')
        config = {
            "configurable": {
                # The passenger_id is used in our flight tools to
                # fetch the user's flight information
                # Checkpoints are accessed by thread_id
                "thread_id": st.session_state.localStore.get('thread_id')
            }
        }
        load_dotenv()
        logo = 'https://images.sftcdn.net/images/t_app-icon-m/p/69c53218-c7a9-11e6-8ce5-5a990553aaad/3424445367/adp-mobile-solutions-logo'
        logo2 = 'https://i.pinimg.com/736x/8b/16/7a/8b167af653c2399dd93b952a48740620.jpg'
        st.set_page_config(page_title="Manthan API Chatbot", page_icon=logo)
        st.header("Manthan API Testing")
        if 'area_key' not in st.session_state:
            st.session_state.area_key = 1
        if 'requests' not in st.session_state:
            st.session_state.requests = []
        if 'responses' not in st.session_state:
            st.session_state['responses'] = ["Hi, I am Project Manthan Testing Bot, How may i assist you?"]
        if 'localStore' not in st.session_state:
            st.session_state.localStore = {}
        if 'upload' not in st.session_state:
            st.session_state.upload = []
        if 'interrupt' not in st.session_state:
            st.session_state.interrupt = []
        if 'intermediate_steps' not in st.session_state:
            st.session_state.intermediate_steps = []
            # system_message = SystemMessagePromptTemplate.from_template(template=manthan_assistant_bot_template)
        system_message = SystemMessagePromptTemplate.from_template(
            template="""Simply return the response as it is , do not change anything""")
        response_container = st.container()
        # container for text box
        textcontainer = st.container()
        # response = " "
        with textcontainer:
            user_question = st.empty()
            user_question = st.chat_input("I am here to help you!", key="input")
            if user_question:
                with st.spinner("Processing"):
                    # prev_response = st.session_state.localStore.get('previous_run_fail')
                    # missing_input = missing_input_status(prev_response)
                    # if missing_input:
                    #     prev_question = st.session_state.requests[-1] if st.session_state.requests else ""
                    # print(st.session_state.localStore.get('previous_chain_responseJson'))
                    if st.session_state.interrupt != "X":
                        print("Step11111111111")
                        events = implementation_graph.stream(
                                {"messages": ("user", user_question)}, config, stream_mode="values")
                        print("after graph")
                        for event in events:
                            st.session_state.localStore['event'] = event
                            _print_event(event, _printed)
                        print("Response came from graph.... now taking snapshot.....")
                        snapshot = implementation_graph.get_state(config)
                        print(snapshot)
                        st.session_state.localStore['snapshot'] = snapshot
                        if snapshot.next:

                            if snapshot.next[0] == "implementation_initiate_tools":
                                st.session_state.interrupt = "X"
                                print("Its got interrupted at implementation_initiate_tools.....")
                                #We have an interrupt! The agent is trying to use a tool, and the user can approve or deny it
                                # Note: This code is all outside of your graph. Typically, you would stream the output to a UI.
                                # Then, you would have the frontend trigger a new run via an API call when the user has provided input.
                                response = "Looks like you are onboarding a client. Please provide source_hcm , target_hcm and salesforce_id"
                    elif st.session_state.interrupt == "X":
                        st.session_state.interrupt = ""
                        print("step222222222", st.session_state.interrupt)
                        if user_question:
                            print("user answer.........."+user_question)
                            # Just continue
                            prev_question = st.session_state.requests[-1] if st.session_state.requests else ""
                            tool_call_id = st.session_state.localStore.get('snapshot').values["messages"][-1].tool_calls[0]["id"]
                            content = prev_question + " " + user_question
                            tool_message = [
                                {"tool_call_id": tool_call_id, "type": "user", "content": content}
                            ]
                            implementation_graph.update_state(config, {"messages": tool_message}, as_node="implementation_initiate_tools")
                            #response = implementation_graph.invoke(config, {"messages": tool_message})
                            response = implementation_graph.invoke(
                                    #{"messages": ("user", prev_question + " " + user_question)}, config
                                    #None, config
                                    # {
                                    #     "messages": [
                                    #         ToolMessage(
                                    #             tool_call_id=st.session_state.localStore.get('event')["messages"][-1].tool_calls[0]["id"],
                                    #             content=prev_question + " " + user_question,
                                    #         )
                                    #     ]
                                    # }, config
                                    {"messages": tool_message}, config
                                )
                        else:
                            # Satisfy the tool invocation by
                            # providing instructions on the requested changes / change of mind
                            response = implementation_graph.invoke(
                                             {
                                            "messages": [
                                                ToolMessage(
                                                    tool_call_id=st.session_state.localStore.get('event')["messages"][-1].tool_calls[0]["id"],
                                                    content=f"API call denied by user. Reasoning: '{user_question}'. Continue assisting, accounting for the user's input.",
                                                )
                                            ]
                                        },
                                        config,
                                    )
                            # st.session_state.interrupt = " "
                    # snapshot = implementation_graph.get_state(config)
                        # user_question = prepare_input(prev_question, prev_response, user_question)
                    #     response = "test"
                    print(response)
                    st.session_state.requests.append(user_question)
                    st.session_state.responses.append(response)

        if st.session_state.upload == 'X':
            with st.sidebar:
                st.subheader("Your documents")
                pdf_docs = st.file_uploader(
                    "Upload your PDFs here and click on 'Process'", accept_multiple_files=True)
                if st.button("Process"):
                    with st.spinner("Processing"):
                        upload_file(pdf_docs)
                        user_question = st.session_state.requests.pop(-1)
                        # response = implementation_graph.invoke(user_question)

                        message("Data has been extracted from file successfully : ")
                        st.session_state.upload = ' '
                        # st.rerun()
                        st.markdown("""
                                     <style>
                                     [data-testid="stSidebar"] {
                                         display: none
                                     }
                                     [data-testid="collapsedControl"] {
                                         display: none
                                     }
                                     </style>
                                     """, unsafe_allow_html=True)
                        # st.error(response['finalResponse'])
                        print("_________________________________________________")
                        # st.session_state.intermediate_steps.append(response['intermediate_steps'][0][-1])
                        # st.session_state.requests.append(user_question)
                        # response = response['finalResponse']
                        # st.session_state.responses.append(response)
                        # print("test",response)
        with response_container:
            if st.session_state['responses']:
                for i in range(len(st.session_state['responses'])):
                    message(st.session_state['responses'][i], key=str(i), logo=logo)
                    if i < len(st.session_state['requests']):
                        message(st.session_state["requests"][i], is_user=True, key=str(i) + '_user', logo=logo2)

    except Exception as e:
        st.error("Something went wrong. Please restart the application.")
        print(f"Error details: {str(e)}")




if __name__ == '__main__':
    # print("Hello Langgraph")
    # print(os.environ["OPENAI_API_KEY"])
    main()