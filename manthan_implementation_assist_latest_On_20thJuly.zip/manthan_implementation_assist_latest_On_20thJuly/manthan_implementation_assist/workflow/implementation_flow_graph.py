from langgraph.checkpoint.sqlite import SqliteSaver
from langgraph.graph import StateGraph, END
import sqlite3

from IPython.display import Image, display

from state.implementation_state import ImplementationState
from tools.implementation_assistant_tools import *
from tools.extraction_tools import *
from workflow.implementation_flow_graph_utils import create_entry_node, create_tool_node_with_fallback, pop_dialog_state
from agents.extraction_agent import extraction_agent_runnable, extraction_safe_tools, \
    extraction_sensitive_tools, route_extraction_agent
from agents.implementation_assistant import (implementation_assistant_runnable, implementation_assistant_tools,
                                             route_to_workflow, route_implementation_assistant, ImplementationAssistant,
                                             implementation_initiate_tools)


def implementation_info(state : ImplementationState):
    return {"implementation_info": fetch_implementation_info.invoke({})}



builder = StateGraph(ImplementationState)
builder.add_node("fetch_implementation_info", implementation_info)
builder.set_entry_point(("fetch_implementation_info"))

# File Extraction agent
builder.add_node(
"enter_extraction_agent",
create_entry_node("File extraction Agent", "extraction_agent")
)
builder.add_node("ask_human",ask_human)
builder.add_node("ask_upload", ask_upload)
builder.add_node("extraction_agent", ImplementationAssistant(extraction_agent_runnable))
builder.add_edge("enter_extraction_agent", "extraction_agent")
builder.add_node("extraction_sensitive_tools", create_tool_node_with_fallback(extraction_sensitive_tools))
builder.add_node("extraction_safe_tools", create_tool_node_with_fallback(extraction_safe_tools))
builder.add_edge("ask_human","implementation_assistant")

builder.add_edge("extraction_sensitive_tools", "extraction_agent")
builder.add_edge("extraction_safe_tools", "extraction_agent")
builder.add_conditional_edges("extraction_agent", route_extraction_agent)
builder.add_edge("ask_upload","extraction_agent")

builder.add_node("goto_implementation_assistant", pop_dialog_state)
builder.add_edge("goto_implementation_assistant", "implementation_assistant")



# Implementation Assistant

builder.add_node("implementation_assistant", ImplementationAssistant(implementation_assistant_runnable))

####### New Flow ######
builder.add_node("implementation_initiate_tools", create_tool_node_with_fallback(implementation_initiate_tools))
#builder.add_node("initiate_binding", bind_implementation)
#builder.add_edge("initiate_implementation", "initiate_binding")
#builder.add_edge("initiate_binding", "extraction_agent")
####### END of New Flow ############

builder.add_node("implementation_assistant_tools", create_tool_node_with_fallback(implementation_assistant_tools))


# Implementation Assistant can route to one of the delegated agents or assistants,
# directly use a tool, or directly respond to the user

builder.add_conditional_edges(
"implementation_assistant",
route_implementation_assistant,
{
    "enter_extraction_agent": "enter_extraction_agent",
    "implementation_assistant_tools": "implementation_assistant_tools",
    "implementation_initiate_tools": "implementation_initiate_tools",
    "ask_human":"ask_human",
    END: END,
},
)
builder.add_edge("implementation_assistant_tools","implementation_assistant")
builder.add_edge("implementation_initiate_tools","implementation_assistant")

builder.add_conditional_edges("fetch_implementation_info", route_to_workflow)

# Compile graph
memory = SqliteSaver.from_conn_string(":memory:")
implementation_graph = builder.compile(
    checkpointer=memory,
    interrupt_before=[
        # "implementation_initiate_tools",
        # "extraction_sensitive_tools",
        "ask_human",
        "ask_upload"
    ],
)


if __name__ == '__main__':
    #try:
        #display(Image(get_implementation_graph().get_graph(xray=True).draw_mermaid_png()))
        print(implementation_graph.get_graph().draw_mermaid())
    #except Exception:
        # This requires some extra dependencies and is optional
    #    pass