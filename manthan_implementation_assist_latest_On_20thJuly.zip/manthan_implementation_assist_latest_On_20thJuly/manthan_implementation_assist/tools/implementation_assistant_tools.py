from langchain_core.tools import tool
from state.implementation_state import ImplementationState
from repository.implementation_repository import *


@tool
def fetch_implementation_info() -> dict:
      """ Fetch the details about the implementations on which user is working on.

      Returns: All the details needed to start the implementation
      """
      return  { "messages":" Required details are present Source HCM :Paylocity, Target HCM : WFN , Salesorderid: 567888" }
@tool
def ask_human():
    """call this if user asks to onboard the client"""
    pass
@tool
def initiate_implementation() -> dict:
    """call this if user asks to initiate implementation"""
    # implementationState['implementation_info']
    # call initiate_implementation API
    print("Its initiate_implementation..........................")
    return {"messages":"initiate implemented with reference id 6789999"}


@tool
def bind_implementation() -> dict:
    """ Call this tool if user wants to bind implementation with salesforceid """
    # call bind_implementation API
    print("Its bind_implementation..............................")
    return {"messages": "its bind_implementation, bind implementation refrence id ABCD1456"}


@tool
def implementation_info(implementation_ref_id) -> dict:
    """call this tool if user wants to know information or details about a particular implementation reference id
    user will provide respective implementation id"""
    print(implementation_ref_id)
    return {"messages": str(get_implementation_info(implementation_ref_id))}


@tool
def list_implementations() -> dict:
    """call this tool if user wants to list out all the implementations
    """
    implementation_list = get_implementations_list()
    return {"messages": str(implementation_list)}
