import os
from dotenv import load_dotenv
#from langchain.chat_models import ChatOpenAI
from langchain.llms import OpenAI
from langchain_openai import ChatOpenAI

# Load .env variables
load_dotenv()

#LLM initilaization & configuration

open_ai_key = os.getenv("OPENAI_API_KEY")

def getChatOpenAILLM(model_name: str="", temperature : float=0, max_retries: int=3 ):
    return ChatOpenAI(temperature=temperature)

def getOpenAILLM(model_name: str="", temperature : float=1, max_retries: int=3 ):
    return OpenAI(temperature=temperature)


