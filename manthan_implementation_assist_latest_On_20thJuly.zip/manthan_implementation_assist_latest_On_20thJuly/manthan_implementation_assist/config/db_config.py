from pymongo.mongo_client import MongoClient
import certifi

uri = "mongodb+srv://pariwartan27:OuKnLrc5lsaYfjYH@cluster108.bv4ahwb.mongodb.net/?retryWrites=true&w=majority&appName=Cluster108"

def getMongoDBClient(db_name: str):
    client = MongoClient(uri, tlsCAFile=certifi.where())
    db = client[db_name]
    return db

def getMongoDBCollection(collection_name: str):
    db = getMongoDBClient("Pari108")
    collection = db[collection_name]
    return collection

if __name__ == '__main__':
    print(getMongoDBCollection("manthan"))